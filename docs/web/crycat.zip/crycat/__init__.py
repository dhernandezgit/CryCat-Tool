"""CryCat - colocación óptima de imágenes para Cricut."""

__version__ = "1.4.0"
APP_NAME = "CryCat"
