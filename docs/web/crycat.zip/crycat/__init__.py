"""CryCat - colocación óptima de imágenes para Cricut."""

__version__ = "1.4.2"
APP_NAME = "CryCat"
