"""CryCat - colocación óptima de imágenes para Cricut."""

__version__ = "2.9.33"
APP_NAME = "CryCat"
AUTOR = "Daniel Hernández Ferrándiz y Wivi.eve"
