"""Optimizador de colocación de imágenes (CryCat).

Empaqueta instancias (copias normales y minis) en el área recortable de
Cricut (polígono escalonado) con:

  * MaxRects con heurísticas BSSF / BAF / BL
  * múltiples órdenes de inserción y reinicios aleatorios dentro de un
    presupuesto de tiempo -> método "auto" elige el mejor resultado
  * rotación: no / 90º / cualquier ángulo (bbox conservadora del giro)
  * espacio entre elementos configurable (se infla cada elemento spacing/2
    por lado, con lo que el hueco real entre elementos es `spacing`)
  * minis: rellenan el espacio sobrante tras las copias normales, con
    tamaño mínimo, tope de reescalado y política (iguales / grandes)
  * elementos fijados por el usuario (pin) que se respetan
  * multipágina: first-fit; mínimo número de páginas posible

Trabaja en mm, con origen (0,0) en la esquina superior izquierda del bbox
del área recortable de cada página.
"""

from __future__ import annotations

import random
import time
from dataclasses import dataclass, field

import numpy as np
from PIL import Image

from .geometry import CutArea, rect_inside_polygon, rotated_size
from .i18n import tr

EPS = 1e-7
# "cualquier ángulo": pasos de 15º INCLUYENDO 90/180/270 (antes faltaban)
FREE_ANGLES = (15, 30, 45, 60, 75, 90, 105, 120, 135, 150, 165, 180, 270)


@dataclass
class Instance:
    """Una copia (normal o mini) que colocar."""

    uid: str
    asset_id: str
    name: str
    w: float          # mm sin rotar (recortada)
    h: float
    mini: bool = False


@dataclass
class Placement:
    uid: str
    asset_id: str
    page: int
    x: float          # mm, coords ABSOLUTAS de la página (origen sup-izq)
    y: float
    w: float          # tamaño colocado (bbox del giro ya aplicado)
    h: float
    angle: float = 0.0
    mini: bool = False
    scale: float = 1.0
    pinned: bool = False
    rata: bool = False
    rot90: bool = False
    # tamaño PEDIDO sin girar (mm). En giros libres la caja `w`/`h` es
    # conservadora (bbox del rectángulo girado) y el render debe escalar la
    # imagen a ESTE tamaño, no a la caja: si no, la pieza se imprime más
    # grande de lo pedido y el contorno no cuadra con el dibujo.
    w0: float = 0.0
    h0: float = 0.0


@dataclass
class PackResult:
    placements: list[Placement] = field(default_factory=list)
    pages: int = 0
    efficiency: float = 0.0
    densidad: float = 0.75      # densidad media de las siluetas (complejidad)
    method: str = ""
    elapsed_s: float = 0.0
    unplaced: list[str] = field(default_factory=list)
    warnings: list[str] = field(default_factory=list)
    cell: float = 0.0           # rejilla (mm) con la que se calculó
    compacidad: float = 0.0     # área (mm²) del bbox ocupado: menor = más recogido


def _inflate(w: float, h: float, spacing: float) -> tuple[float, float]:
    return w + spacing, h + spacing


class Bin:
    """Una página: rects libres (MaxRects) + colocaciones."""

    def __init__(self, area: CutArea, spacing: float):
        self.area = area
        self.spacing = spacing
        bx, by, bw, bh = area.bbox
        # Contenedor único = bbox del área recortable; las muescas de las
        # esquinas se restan como obstáculos (invariantes MaxRects intactos).
        self.free: list[list[float]] = [[bx, by, bw, bh]]
        for nx, ny, nw, nh in area.notches:
            self.subtract(nx, ny, nw, nh)
        self.placed: list[Placement] = []

    def subtract(self, rx: float, ry: float, rw: float, rh: float) -> None:
        """Resta un rect ocupado de todos los libres (split MaxRects)."""
        new_free: list[list[float]] = []
        for fx, fy, fw, fh in self.free:
            if rx >= fx + fw - EPS or rx + rw <= fx + EPS or \
               ry >= fy + fh - EPS or ry + rh <= fy + EPS:
                new_free.append([fx, fy, fw, fh])
                continue
            if rx > fx:
                new_free.append([fx, fy, rx - fx, fh])
            if rx + rw < fx + fw:
                new_free.append([rx + rw, fy, fx + fw - (rx + rw), fh])
            if ry > fy:
                new_free.append([fx, fy, fw, ry - fy])
            if ry + rh < fy + fh:
                new_free.append([fx, ry + rh, fw, fy + fh - (ry + rh)])
        kept: list[list[float]] = []
        for i, a in enumerate(new_free):
            contained = False
            for j, b in enumerate(new_free):
                if i != j and a[0] >= b[0] - EPS and a[1] >= b[1] - EPS and \
                   a[0] + a[2] <= b[0] + b[2] + EPS and a[1] + a[3] <= b[1] + b[3] + EPS:
                    contained = True
                    break
            if not contained and a[2] > EPS and a[3] > EPS:
                kept.append(a)
        self.free = kept

    def best_position_score(self, w: float, h: float, heuristic: str = "bssf"
                            ) -> tuple[float, float, object] | None:
        """Mejor (x, y, score) para un rect w x h (ya inflado)."""
        best = None
        best_score = None
        for fx, fy, fw, fh in self.free:
            if fw + EPS < w or fh + EPS < h:
                continue
            if not rect_inside_polygon(self.area.poly, [], fx, fy, w, h):
                continue
            if heuristic == "baf":
                score: object = fw * fh
            elif heuristic == "bl":
                score = (fy, fx)
            else:  # bssf
                score = (min(fw - w, fh - h), fw * fh)
            if best_score is None or score < best_score:
                best, best_score = (fx, fy, score), score
        return best

    def best_position(self, w: float, h: float, heuristic: str = "bssf"
                      ) -> tuple[float, float] | None:
        """Mejor (x, y) para un rect w x h (ya inflado), o None si no cabe."""
        got = self.best_position_score(w, h, heuristic)
        return (got[0], got[1]) if got else None

    def add(self, inst: Instance, x: float, y: float, w: float, h: float,
            angle: float, scale: float, rot90: bool) -> Placement:
        iw, ih = _inflate(w, h, self.spacing)
        self.subtract(x, y, iw, ih)
        p = Placement(uid=inst.uid, asset_id=inst.asset_id, page=0,
                      x=x + self.spacing / 2, y=y + self.spacing / 2,
                      w=w, h=h, angle=angle, mini=inst.mini, scale=scale,
                      rot90=rot90, w0=inst.w, h0=inst.h)
        self.placed.append(p)
        return p

    def is_free_for(self, x: float, y: float, w: float, h: float,
                    skip_uid: str | None = None) -> bool:
        """¿Un elemento w x h en (x,y) respeta polígono, muescas y vecinos?"""
        px, py = x - self.spacing / 2, y - self.spacing / 2
        pw, ph = _inflate(w, h, self.spacing)
        if not rect_inside_polygon(self.area.poly, self.area.notches, px, py, pw, ph):
            return False
        for p in self.placed:
            if skip_uid and p.uid == skip_uid:
                continue
            ox, oy = p.x - self.spacing / 2, p.y - self.spacing / 2
            ow, oh = _inflate(p.w, p.h, self.spacing)
            if not (px + pw <= ox + EPS or px >= ox + ow - EPS or
                    py + ph <= oy + EPS or py >= oy + oh - EPS):
                return False
        return True


def _candidate_sizes(inst: Instance, rot_mode: str
                     ) -> list[tuple[float, float, float, bool]]:
    """Tamaños del bbox ya rotado: (w, h, ángulo visual, es_giro90).

    Modos:  * "no"        -> 0º
            * "90"/"cuadrantes" -> 0, 90, 180 y 270 º
            * "libre"     -> cualquier ángulo (pasos de 15º)
    Nota: al empaquetar por bbox, 180º/270º tienen la misma huella que
    0º/90º, así que solo cambian la orientación visual del resultado.
    """
    sizes: list[tuple[float, float, float, bool]] = [(inst.w, inst.h, 0.0, False)]
    if rot_mode in ("90", "cuadrantes", "cuadrantes4"):
        sizes.append((inst.h, inst.w, 90.0, True))
        sizes.append((inst.w, inst.h, 180.0, False))
        sizes.append((inst.h, inst.w, 270.0, True))
    elif rot_mode == "libre":
        for a in FREE_ANGLES:
            w, h = rotated_size(inst.w, inst.h, a)
            sizes.append((w, h, float(a), False))
    return sizes


def _expand_items(assets: list[dict], settings: dict
                  ) -> tuple[list[Instance], list[dict]]:
    """Normales = TODAS las copias indicadas.

    Los minis van APARTE: no consumen copias; solo rellenan los huecos que
    sobran tras colocar las copias. La cuota de cada elemento decide CUÁNTOS
    minis recibe respecto a los demás (1 = equitativo; 3 = el triple).
    Devuelve (instancias_normales, peticiones_mini).
    """
    normals: list[Instance] = []
    mini_requests: list[dict] = []
    usar_minis = bool(settings.get("usar_minis"))
    for a in assets:
        copies = int(a.get("copies", 1))
        if copies <= 0:
            continue
        for k in range(copies):
            normals.append(Instance(uid=f"{a['id']}#{k}", asset_id=a["id"],
                                    name=a.get("name", ""),
                                    w=a["w_mm"], h=a["h_mm"]))
        if usar_minis and bool(a.get("mini_enabled")):
            mini_requests.append({
                "asset_id": a["id"], "name": a.get("name", ""),
                "w": a["w_mm"], "h": a["h_mm"],
                # cuota: cuántos quieres de este elemento respecto a los demás
                "weight": min(100.0, max(1.0, float(a.get("mini_quota", 1.0)))),
            })
    return normals, mini_requests


def _sort_instances(insts: list[Instance], order: str) -> list[Instance]:
    keyfun = {
        "area": lambda i: (i.w * i.h, max(i.w, i.h), i.uid),
        "alto": lambda i: (i.h, i.w, i.uid),
        "ancho": lambda i: (i.w, i.h, i.uid),
        "perimetro": lambda i: (i.w + i.h, i.w * i.h, i.uid),
    }[order]
    return sorted(insts, key=keyfun, reverse=True)


def _pack_normals(bins: list[Bin], insts: list[Instance], rot_mode: str,
                  heuristic: str, deadline: float | None = None) -> list[str]:
    """Coloca las copias (first-fit entre páginas) eligiendo para CADA objeto
    su mejor combinación de hoja y rotación (pueden ser distintas entre sí).

    Devuelve la lista de uids no colocadas. Llena primero la hoja 1, luego la
    2, etc. Si se pasa `deadline` (tiempo límite) deja de colocar al superarlo.
    """
    unplaced: list[str] = []
    for inst in insts:
        if deadline is not None and time.time() > deadline:
            unplaced.append(inst.uid)
            continue
        best = None  # (score, bin, x, y, w, h, angle, r90)
        for bin_ in bins:
            for (w, h, angle, r90) in _candidate_sizes(inst, rot_mode):
                iw, ih = _inflate(w, h, bin_.spacing)
                got = bin_.best_position_score(iw, ih, heuristic)
                if got is None:
                    continue
                x, y, score = got
                if best is None or score < best[0]:
                    best = (score, bin_, x, y, w, h, angle, r90)
        if best is None:
            unplaced.append(inst.uid)
            continue
        _, bin_, x, y, w, h, angle, r90 = best
        bin_.add(inst, x, y, w, h, angle, 1.0, r90)
    return unplaced


def _open_bin_for(bins: list[Bin], area: CutArea, spacing: float,
                  solo_una: bool = False) -> Bin:
    # modo «Solo 1 página»: no se abre otra página; se devuelve la primera
    # (lo que no quepa se quedará sin colocar y se avisará)
    if solo_una and bins:
        return bins[0]
    b = Bin(area, spacing)
    bins.append(b)
    return b


def _place_minis(bins: list[Bin], requests: list[dict], settings: dict,
                 result: PackResult) -> None:
    """Rellena los huecos con minis (copias EXTRA que no cuentan).

    La cuota de cada elemento decide CUÁNTOS minis recibe respecto a los demás
    (1 = reparto equitativo; 3 = el triple; admite decimales): se coloca
    primero el más subrepresentado. El TAMAÑO lo elige el optimizador (lo mayor
    que quepa en cada hueco), acotado por `mini_min_mm` y `mini_max_rescale`, y
    siempre más pequeño que el original (tope duro del 99 %). La política
    'iguales' reutiliza una escala común por elemento.
    """
    if not requests:
        return
    min_mm = float(settings.get("mini_min_mm", 5.0))
    max_res = min(0.99, max(0.01,
                            float(settings.get("mini_max_rescale", 100.0))) / 100.0)
    policy = settings.get("mini_tamanos", "grandes")
    rot_mode = settings.get("mini_rotacion", "no")
    usar_lista = bool(settings.get("mini_usar_lista"))
    lista_modo = str(settings.get("mini_lista_modo", "mm"))
    lista_base = [max(0.5, float(v)) for v in
                  (settings.get("mini_tamanos_lista") or [])]
    peso_total = sum(r["weight"] for r in requests)
    counts = {r["asset_id"]: 0 for r in requests}
    comunes: dict[str, float] = {}
    total = 0
    cap = 5000

    while total < cap:
        requests.sort(
            key=lambda r: r["weight"] / peso_total
            - counts[r["asset_id"]] / (total + 1.0), reverse=True)
        hecho = False
        for req in requests:
            base = max(min(req["w"], req["h"]), 1e-6)
            # con la LISTA activa el mínimo se ignora (manda la lista)
            s_floor = 1e-6 if usar_lista else min_mm / base
            if s_floor > max_res:
                continue
            got = None
            suelo = 0.0 if usar_lista else min_mm
            if policy == "iguales" and req["asset_id"] in comunes:
                got = _try_place_scaled(bins, req["w"], req["h"],
                                        comunes[req["asset_id"]], suelo,
                                        rot_mode)
            else:
                base_lado = max(min(req["w"], req["h"]), 1e-6)
                lista = ([v / base_lado for v in lista_base]
                         if lista_modo == "mm"
                         else [v / 100.0 for v in lista_base])
                for s in _escalas_mini(s_floor, max_res, usar_lista, lista):
                    got = _try_place_scaled(bins, req["w"], req["h"], s,
                                            suelo, rot_mode)
                    if got:
                        comunes.setdefault(req["asset_id"], s)
                        break
            if got is None:
                continue
            bin_, x, y, ws, hs, angle, s, r90 = got
            inst = Instance(uid=f"{req['asset_id']}#mini{total}",
                            asset_id=req["asset_id"],
                            name=req.get("name", ""), w=req["w"],
                            h=req["h"], mini=True)
            bin_.add(inst, x, y, ws, hs, angle, s, r90)
            counts[req["asset_id"]] += 1
            total += 1
            hecho = True
            break
        if not hecho:
            break


def _escalas_mini(s_floor: float, max_res: float, usar_lista: bool,
                  lista: list[float]) -> list[float]:
    """Escalas a probar para un mini (lista deseada o descendente automática)."""
    if usar_lista and lista:
        out = sorted({min(max_res, max(s_floor, s)) for s in lista}, reverse=True)
        return [s for s in out if s >= s_floor - 1e-9]
    out: list[float] = []
    s = max_res
    while s >= s_floor - 1e-9 and len(out) < 12:
        out.append(s)
        s *= 0.75
    return out


def _try_place_scaled(bins: list[Bin], w0: float, h0: float, s: float,
                      min_mm: float, rot_mode: str):
    """Intenta colocar un mini de tamaño base (w0, h0) a escala uniforme s.
    Devuelve (bin, x, y, ws, hs, angle, s, r90) o None. La escala es siempre
    uniforme: nunca se deforma la imagen."""
    ws0, hs0 = w0 * s, h0 * s
    if min(ws0, hs0) < min_mm - 1e-6:
        return None
    for bin_ in bins:
        for (w, h, angle, r90) in _candidate_sizes(
                Instance("t", "", "", w0, h0), rot_mode):
            ws, hs = w * s, h * s
            if min(ws, hs) < min_mm - 1e-6:
                continue
            iw, ih = _inflate(ws, hs, bin_.spacing)
            pos = bin_.best_position(iw, ih, "bssf")
            if pos is not None:
                return (bin_, pos[0], pos[1], ws, hs, angle, s, r90)
    return None


def sil_fracs(masks: dict | None) -> dict[str, float]:
    """Fracción de silueta real (píxeles no transparentes / caja) de cada imagen.

    Se usa para medir la eficiencia de verdad: lo que ocupan las siluetas, no
    las cajas. La rotación no altera el área, así que vale un único valor por
    imagen. Se submuestrea en imágenes grandes para que sea barato.
    """
    out: dict[str, float] = {}
    for aid, img in (masks or {}).items():
        try:
            try:
                a = img.getchannel("A")
            except Exception:
                a = img.convert("RGBA").getchannel("A")
            w, h = a.size
            largo = max(w, h) or 1
            if largo > 1024:
                esc = 1024.0 / largo
                a = a.resize((max(1, int(w * esc)), max(1, int(h * esc))),
                             Image.NEAREST)
            alpha = np.asarray(a)
            total = alpha.size or 1
            out[aid] = float(np.count_nonzero(alpha > 1)) / total
        except Exception:
            continue
    return out


def _run_pack(assets: list[dict], area: CutArea, settings: dict,
              pinned: list[Placement], ordered: list[Instance],
              heuristic: str, method_label: str,
              deadline: float | None = None,
              fracs: dict[str, float] | None = None) -> PackResult:
    # el espacio puede ser NEGATIVO: solapamiento controlado entre piezas
    spacing = float(settings.get("espacio_mm", 2.0))
    rot_mode = settings.get("rotacion", "no")
    solo_una = str(settings.get("paginas_modo", "una")) == "una"
    _, mini_requests = _expand_items(assets, settings)

    bins: list[Bin] = [Bin(area, spacing)]
    for p in pinned:
        iw, ih = _inflate(p.w, p.h, spacing)
        bins[0].subtract(p.x - spacing / 2, p.y - spacing / 2, iw, ih)
        bins[0].placed.append(Placement(
            uid=p.uid, asset_id=p.asset_id, page=0, x=p.x, y=p.y, w=p.w, h=p.h,
            angle=p.angle, mini=p.mini, scale=p.scale, pinned=True, rot90=p.rot90))

    # los fijados ya están pre-colocados: no se reempaquetan
    pinned_uids = {p.uid for p in pinned}
    ordered = [i for i in ordered if i.uid not in pinned_uids]

    unplaced = _pack_normals(bins, ordered, rot_mode, heuristic, deadline)
    if unplaced:
        pending = [i for i in ordered if i.uid in set(unplaced)]
        while pending:
            antes = len(bins)
            extra = _open_bin_for(bins, area, spacing, solo_una)
            still = _pack_normals([extra], pending, rot_mode, heuristic,
                                  deadline)
            if len(still) == len(pending):
                # ni en página nueva: imposible. OJO: en «Solo 1 página»
                # `_open_bin_for` devuelve la hoja existente y aquí NO se
                # puede quitar (se perderían todas las colocaciones; era el
                # bug que dejaba el modo rectángulos con 0 piezas)
                if len(bins) > antes:
                    bins.pop()
                break
            pending = [i for i in pending if i.uid in set(still)]
        unplaced = [i.uid for i in pending]

    result = PackResult(method=method_label, unplaced=list(unplaced))
    _place_minis(bins, mini_requests, settings, result)
    for bi, b in enumerate(bins):
        for p in b.placed:
            p.page = bi
    result.pages = len(bins)
    result.placements = [p for b in bins for p in b.placed]
    used = sum(b.area.area_mm2 for b in bins)
    # eficiencia REAL: área de las siluetas (no de las cajas). OJO: la
    # silueta no cambia de área al girar; el tamaño ORIGINAL del elemento
    # (con su escala) es el que hay que usar, no el bbox rotado
    por_id = {a["id"]: a for a in assets}
    area_sil = 0.0
    for p in result.placements:
        a = por_id.get(p.asset_id)
        if a is not None and fracs:
            s = float(p.scale or 1.0)
            area_sil += (float(a.get("w_mm", 0)) * float(a.get("h_mm", 0))
                         * s * s * fracs.get(p.asset_id, 1.0))
        else:
            area_sil += p.w * p.h
    result.efficiency = area_sil / used if used > 0 else 0.0
    if fracs and result.placements:
        vals = [fracs.get(p.asset_id, 1.0) for p in result.placements]
        result.densidad = min(1.0, max(0.05, sum(vals) / len(vals)))
    if result.unplaced:
        result.warnings.append(
            tr("{n} copias no caben en el área recortable",
               n=len(result.unplaced)))
    return result


def optimize(assets: list[dict], area: CutArea, settings: dict,
             pinned: list[Placement] | None = None,
             progress=None, masks=None) -> PackResult:
    """Optimiza la colocación.

    assets: [{id, name, w_mm, h_mm, copies, mini_enabled, mini_pct}]
    masks:  {asset_id: PIL RGBA} para el empaquetado por silueta real
    pinned: placements fijos (se reubican en páginas nuevas).
    progress(frac 0..1, pages) para la barra de estado.
    """
    t0 = time.time()
    method = str(settings.get("opt_metodo", "greedy")).lower()
    margen = max(0.0, float(settings.get("margen_mm", 0.0)))
    if margen > 0:
        from .geometry import inset_area
        area = inset_area(area, margen)

    # Estrategia: el empaquetado por CAJAS es un ATAJO para trabajos HOLGADOS
    # (cabe todo de sobra en una hoja) y para cuando no hay siluetas. Si el
    # trabajo NO es holgado (o hay minis, que aprovechan los huecos), se va
    # DIRECTO al empaquetado por silueta: las pasadas por cajas se tirarían y
    # solo gastan tiempo (bug real: hasta 12 pasadas inútiles antes de empezar).
    fracs = sil_fracs(masks) if masks else None

    pinned = [p for p in (pinned or []) if p.pinned]
    from .config import tiempo_optimo

    n_prev = sum(max(0, int(a.get("copies", 1))) for a in assets) + \
        len(pinned or [])
    t_max = max(0.5, tiempo_optimo(settings, n_prev))
    deadline = t0 + t_max
    normals, _ = _expand_items(assets, settings)

    ocupa = sum(float(a.get("w_mm", 0)) * float(a.get("h_mm", 0))
                * max(0, int(a.get("copies", 1))) for a in assets)
    holgado = ocupa < 0.15 * max(1.0, area.area_mm2)
    # MODO CHAPAS: las piezas son redondas y no se giran (ángulo 0) en
    # NINGÚN camino (ni cajas ni siluetas)
    forma = str(settings.get("modo_forma", "siluetas"))
    if forma == "redondas":
        settings = dict(settings, rotacion="no", mini_rotacion="no")
    # MODO CARTELES: los rectángulos SON cajas, así que se prueba PRIMERO el
    # empaquetado por cajas (exacto y rapidísimo). Si se complica (queda algo
    # sin colocar o no cabe en una hoja) se recurre a las SILUETAS con el
    # presupuesto que quede.
    rectangulos = forma == "rectangulos"
    if (masks and (settings.get("rata_activo")
                   or (not rectangulos
                       and (settings.get("usar_minis") or not holgado)))):
        # el MODO RATA necesita el empaquetado por silueta (coloca las copias
        # extra en los márgenes después): con cajas nunca se colocarían
        from .silhouette import pack as sil_pack

        # LÍNEA BASE por CAJAS (2 variantes, rapidísimas y seguras): la
        # silueta solo se queda si MEJORA (menos páginas/sin colocar). Así
        # nunca se devuelve un resultado peor que el de las cajas.
        def _clave_cajas(r):
            return (len(r.unplaced), max(0, r.pages), -r.efficiency)

        # LÍNEA BASE por cajas: UNA variante y con tope de tiempo (para no
        # robar presupuesto). Con rectángulos (o formas que llenan su caja)
        # suele ganar; con círculos pierde y decide la silueta.
        base: PackResult | None = None
        if not settings.get("usar_minis"):
            fin_base = min(deadline, time.time() + min(2.0, 0.3 * t_max))
            r = _run_pack(assets, area, settings, pinned,
                          _sort_instances(normals, "area"), "bssf",
                          "bssf/area", fin_base, fracs=fracs)
            if r.placements:
                base = r
        restante = (max(0.5, deadline - time.time()) if base is not None
                    else None)
        res = sil_pack(assets, masks, area, settings, pinned, progress,
                       presupuesto_s=restante)
        if base is not None and _clave_cajas(base) < _clave_cajas(res):
            base.elapsed_s = time.time() - t0
            return base
        return res

    if rectangulos:
        # MODO RECTÁNGULOS: cajas, súper rápido: presupuesto corto
        deadline = min(deadline, t0 + 3.0)
    if method == "maxrects":
        variants = [(o, h) for o in ("area", "alto") for h in ("bssf", "baf", "bl")]
    elif method == "skyline":
        variants = [("area", "bl")]
    else:
        variants = [(o, h) for o in ("area", "alto", "ancho", "perimetro")
                    for h in ("bssf", "baf", "bl")]

    best: PackResult | None = None
    rnd = random.Random(20260925)
    i = 0
    while True:
        if i < len(variants):
            order, heur = variants[i]
            ordered = _sort_instances(normals, order)
            label = f"{heur}/{order}"
        else:
            heur = ("bssf", "baf", "bl")[i % 3]
            shuffled = normals[:]
            rnd.shuffle(shuffled)
            ordered = shuffled
            label = f"{heur}/random{i}"
        res = _run_pack(assets, area, settings, pinned, ordered, heur, label,
                        deadline, fracs=fracs)
        def _clave(r):
            return (0 if r.pages > 0 else 1, len(r.unplaced),
                    max(0, r.pages), -r.efficiency)

        if best is None or _clave(res) < _clave(best):
            best = res
        i += 1
        if progress:
            # escala de la fase por cajas: 5%..90% (el resto es el cierre)
            progress(0.05 + 0.85 * min(0.99, i / (i + 2)), best.pages)
        # mientras la hoja no esté llenísima, basta con un resultado rápido
        if (method == "auto" and not best.unplaced
                and best.efficiency < 0.80):
            break
        if method != "auto":
            if i >= len(variants):
                break
        elif time.time() > deadline or i >= 120:
            break
    assert best is not None
    # El resultado por cajas solo vale si el trabajo era HOLGADO y cabe en una
    # hoja; si no (aquí solo se llega con trabajos holgados o sin máscaras),
    # manda la SILUETA, que encaja y aprovecha de verdad. En modo carteles
    # esto es el "si se complica": cajas primero y siluetas si no basta.
    if masks and not rectangulos and (best.unplaced or best.pages > 1):
        from .silhouette import pack as sil_pack
        # presupuesto RESTANTE: el intento por cajas ya gastó parte
        restante = max(0.5, deadline - time.time())
        return sil_pack(assets, masks, area, settings, pinned, progress,
                        presupuesto_s=restante)
    best.elapsed_s = time.time() - t0
    return best


def try_move(placements: list[Placement], uid: str, x: float, y: float,
             area: CutArea, spacing: float) -> Placement | None:
    """Mueve (y fija) un elemento si la posición es válida."""
    target = next((p for p in placements if p.uid == uid), None)
    if target is None:
        return None
    probe = Bin(area, spacing)
    probe.placed = [p for p in placements
                    if p.page == target.page and p.uid != uid]
    if not probe.is_free_for(x, y, target.w, target.h):
        return None
    target.x, target.y = x, y
    target.pinned = True
    return target
