"""Geometría de páginas y del área recortable de Cricut.

Modelo del área recortable (Print Then Cut):

El área recortable NO es un rectángulo: Cricut reserva las esquinas de la
página para las marcas de registro del sensor. La guía roja de Design Space
("Área recortable" / "Cuttable area") es un polígono escalonado de **5
bandas** (2 escalones por esquina, 20 vértices):

    *  banda central (fila superior): ancho reducido (~0.67 del bbox)
    *  banda intermedia: ~0.92 del bbox
    *  banda central: todo el ancho / toda la altura (máximos oficiales)
    *  y su reflejo abajo

Un diseño rectangular que use la altura máxima no puede usar a la vez la
anchura máxima (documentado por Cricut) -> escalones en las esquinas.

Dimensiones máximas oficiales (help.cricut.com, "How large can I Print Then
Cut?", revisado 2026-08; serie Maker = Cricut Maker 5 incluida) y, para A4,
calibradas directamente sobre la referencia del usuario
`assets/Cricut_A5_Limites_300ppp.png` (la imagen es un A4 completo: el negro
es el límite y el blanco la superficie útil):

    A4      (210 x 297)   -> max horizontal 186.0  x max vertical 272.3
                              (márgenes ~12 mm, medidos en la referencia)
    Letter  (215.9x279.4) -> max horizontal 189.0  x max vertical 252.5
    Legal   (215.9x355.6) -> max horizontal 189.0  x max vertical 328.7
    Tabloid (279.4x431.8) -> max horizontal 252.5  x max vertical 404.9
    A3      (297 x 420)   -> max horizontal 270.0  x max vertical 392.0
    A5      (148 x 210)   -> max horizontal 131.0  x max vertical 192.5

Las fracciones de las bandas se midieron píxel a píxel sobre esa referencia.
"""

from __future__ import annotations

import math
from dataclasses import dataclass, field

from .i18n import tr

# Máximos oficiales por tamaño de papel (retrato): (max_ancho, max_alto) en mm
OFFICIAL_MAX: dict[str, tuple[float, float]] = {
    "A4": (186.0, 272.3),  # calibrado sobre la referencia A4 del usuario
    "Letter": (189.0, 252.5),
    "Legal": (189.0, 328.7),
    "Tabloid": (252.5, 404.9),
    "A3": (270.0, 392.0),
    "A5": (131.0, 192.5),  # proporcional (A4/√2)
}

# Tamaños de papel en mm (retrato): (ancho, alto)
PAPER_SIZES: dict[str, tuple[float, float]] = {
    "A4": (210.0, 297.0),
    "Letter": (215.9, 279.4),
    "Legal": (215.9, 355.6),
    "Tabloid": (279.4, 431.8),
    "A3": (297.0, 420.0),
    "A5": (148.0, 210.0),
}

# --- marcas de registro (sensor) de Cricut ------------------------------
# Las marcas son las MISMAS para todos los tamaños de papel (fiduciales del
# sensor). Medidas sobre la referencia del usuario `assets/CricutMarcas.png`
# (un A4 a 300 ppp impreso por Design Space):
#   * soporte de cada marca (cuadrado que ocupa):  25.32 mm
#   * grosor de las barras en L:                    1.44 mm
#   * esquina exterior de las marcas (A4 vertical): (13.63, 13.21) arriba
#     izquierda y (196.09, 280.08) abajo derecha
MARK_SIZE = 25.32      # lado del soporte de cada marca (mm)
MARK_THICK = 1.44      # grosor de las barras (mm)
MARK_GAP = 0.5         # margen extra para que nada toque la tinta
# distancia de la esquina EXTERIOR del soporte al FILO INTERIOR de la L
# (medida sobre las marcas reales que se imprimen): es lo que se usa para
# abrazar el contenido con la TINTA, no con el soporte (transparente)
MARK_INK = 1.72
MARKS_A4 = (13.63, 13.21, 196.09, 280.08)   # A4 vertical (referencia real)

# --- escalones de la GUÍA DE CORTE oficial ------------------------------
# Medidos sobre `assets/Cricut_A5_Limites_300ppp.png` (borde blanco sobre
# negro, página A5 148x210): la esquina del área retrocede primero ~5.5 mm y
# luego ~22.5 mm (en mm desde la esquina de la caja). Antes se derivaban del
# tamaño de las marcas (25.32) y NO coincidían con la referencia.
STEP1 = 5.5
STEP2 = 22.5

# --- máximo RECTANGULAR real de Print Then Cut de Design Space ----------
# Para un diseño RECTANGULAR, Design Space no deja usar todo el área
# escalonada: su auto-redimensionado encaja el diseño en el mayor
# rectángulo interior. Tabla verificada por la comunidad (repetidamente
# medida; Reddit r/cricut + medidores de área), en pulgadas → mm:
#   A4      6.587 x 10.004 in  → 167.31 x 254.10 mm
#   Letter  6.823 x  9.323 in  → 173.30 x 236.80 mm
#   Legal   6.823 x 12.32  in  → 173.30 x 312.93 mm
#   Tabloid 9.32  x 15.32  in  → 236.73 x 389.13 mm
#   A3      10.024 x 14.82 in  → 254.61 x 376.43 mm
DS_RECT_MAX: dict[str, tuple[float, float]] = {
    "A4": (167.31, 254.10),
    "Letter": (173.30, 236.80),
    "Legal": (173.30, 312.93),
    "Tabloid": (236.73, 389.13),
    "A3": (254.61, 376.43),
}
# un pelín de seguridad (redondeo a píxeles al guardar a 144 ppp ≈ 0.18 mm)
DS_SAFE_EPS = 0.3


def marks_rect(page_w: float, page_h: float,
               bbox: tuple[float, float, float, float],
               paper_key: str | None = None
               ) -> tuple[float, float, float, float]:
    """Rectángulo EXTERIOR de las 4 marcas de registro (mm).

    Para A4 vertical se usan las posiciones OFICIALES medidas sobre la
    referencia (como las imprime Design Space); en el resto de tamaños y en
    apaisado se anclan a las esquinas del área máxima (mismo tamaño de
    marca). El área recortable se deriva de aquí, así las piezas NUNCA tocan
    las marcas.
    """
    if (paper_key == "A4" and page_w < page_h
            and abs(page_w - 210.0) < 0.5 and abs(page_h - 297.0) < 0.5):
        return MARKS_A4
    x0, y0, bw, bh = bbox
    return (x0, y0, x0 + bw, y0 + bh)


def marks_rect_for(area: "CutArea") -> tuple[float, float, float, float]:
    """Marcas de una `CutArea` ya calculada (posiciones oficiales)."""
    return marks_rect(area.page_w, area.page_h, area.bbox,
                      _match_paper(area.page_w, area.page_h))


def marks_adaptadas(caja_contenido: tuple[float, float, float, float] | None,
                    oficial: tuple[float, float, float, float],
                    gap: float = 1.0
                    ) -> tuple[float, float, float, float]:
    """Marcas cuyo FILO INTERIOR abraza el contenido (sin taparlo).

    La L de cada marca queda a `gap` mm del píxel más externo del contenido:
    la barra vertical izquierda delimita el borde izquierdo, la horizontal
    superior el borde superior, etc. Las 4 a la vez, así los CUATRO lados
    quedan delimitados por la tinta (como en una impresión de Design Space).

    Los soportes son transparentes y pueden salirse de la hoja; la TINTA (la
    L) siempre queda dentro porque el área recortable deja más de
    `gap + MARK_INK` mm a cada lado. Sin contenido, devuelve las oficiales.
    """
    if caja_contenido is None:
        return oficial
    cx0, cy0, cx1, cy1 = caja_contenido
    t = MARK_INK
    return (cx0 - gap - t, cy0 - gap - t, cx1 + gap + t, cy1 + gap + t)

# Perfiles de máquina (máximos de A4 en mm); None = usa los estándar.
# Toda la serie Maker (Maker, Maker 3, Maker 5) comparte el mismo patrón de
# área recortable y de marcas: solo cambia el nombre.
MACHINE_A4_OVERRIDE: dict[str, tuple[float, float] | None] = {
    "maker3": None,            # Cricut Maker 3 (por defecto)
    "maker": None,             # Cricut Maker (original)
    "maker5": None,            # Cricut Maker 5 (serie Maker)
    "estandar": None,          # Joy Xtra / Explore / Venture
    "joy": (78.0, 269.8),      # Cricut Joy 2: máx horizontal 3.07 in
}

MACHINE_LABELS: dict[str, str] = {
    "maker3": "Cricut Maker 3",
    "maker": "Cricut Maker",
    "maker5": "Cricut Maker 5",
    "estandar": "Explore / Joy Xtra / Venture (estándar)",
    "joy": "Cricut Joy 2",
}

MAQUINA_POR_DEFECTO = "maker3"


def machine_label(m: str | None) -> str:
    """Nombre visible de la máquina (Maker 3 si no se reconoce)."""
    return MACHINE_LABELS.get(str(m or ""), MACHINE_LABELS[MAQUINA_POR_DEFECTO])


@dataclass(frozen=True)
class CutArea:
    """Área recortable de una página: polígono escalonado + bbox."""

    page_w: float          # mm, página completa (orientación elegida)
    page_h: float
    poly: list[tuple[float, float]]   # vértices en mm, origen = esquina sup-izq de la página
    bbox: tuple[float, float, float, float]  # (x0, y0, w, h) en mm, centrado en la página
    notches: list[tuple[float, float, float, float]]  # rects prohibidos (esquinas), mm
    machine: str = "estandar"

    @property
    def bbox_w(self) -> float:
        return self.bbox[2]

    @property
    def bbox_h(self) -> float:
        return self.bbox[3]

    @property
    def area_mm2(self) -> float:
        return polygon_area(self.poly)


def polygon_area(poly: list[tuple[float, float]]) -> float:
    """Área de un polígono simple (fórmula del zapato), en mm²."""
    n = len(poly)
    s = 0.0
    for i in range(n):
        x1, y1 = poly[i]
        x2, y2 = poly[(i + 1) % n]
        s += x1 * y2 - x2 * y1
    return abs(s) / 2.0


def polygon_contains(poly: list[tuple[float, float]], x: float, y: float) -> bool:
    """Point-in-polygon (ray casting). Para polígonos rectilíneos convexos por
    tramos también vale la comprobación por rectángulos, pero se usa el test
    general para robustez."""
    inside = False
    n = len(poly)
    j = n - 1
    for i in range(n):
        xi, yi = poly[i]
        xj, yj = poly[j]
        if (yi > y) != (yj > y):
            x_int = (xj - xi) * (y - yi) / (yj - yi) + xi
            if x < x_int:
                inside = not inside
        j = i
    return inside


def rect_inside_polygon(poly: list[tuple[float, float]],
                        notches: list[tuple[float, float, float, float]],
                        x: float, y: float, w: float, h: float,
                        eps: float = 1e-6) -> bool:
    """Cierto si el rectángulo [x, x+w] x [y, y+h] queda dentro del polígono.

    Como el polígono es el bbox menos muescas rectangulares (notches), basta
    con comprobar que el rect está en el bbox y no intersecta ninguna muesca.
    """
    for nx, ny, nw, nh in notches:
        if x < nx + nw - eps and x + w > nx + eps and y < ny + nh - eps and y + h > ny + eps:
            return False
    return True


def _bands_polygon(x0: float, y0: float, bw: float, bh: float
                   ) -> tuple[list[tuple[float, float]], list[tuple[float, float, float, float]]]:
    """Polígono escalonado de 5 bandas (2 escalones por esquina) y sus muescas
    para una caja (x0, y0, bw, bh), con los escalones OFICIALES medidos sobre
    la referencia del usuario (`STEP1`/`STEP2`)."""
    x1 = x0 + bw
    y1 = y0 + bh
    # escalón 1 (el pequeño, ~5.5 mm) y escalón 2 (el grande, ~22.5 mm)
    wx0 = x0 + STEP1
    wx1 = x1 - STEP1
    cx0 = x0 + STEP2
    cx1 = x1 - STEP2
    t1 = y0 + STEP1
    t2 = y0 + STEP2
    t3 = y1 - STEP2
    t4 = y1 - STEP1
    # acotar a la caja y ordenar (por cajas muy pequeñas)
    cx0, cx1 = sorted((min(max(cx0, x0), x1), min(max(cx1, x0), x1)))
    wx0, wx1 = sorted((min(max(wx0, x0), x1), min(max(wx1, x0), x1)))
    t1, t2 = sorted((min(max(t1, y0), y1), min(max(t2, y0), y1)))
    t3, t4 = sorted((min(max(t3, y0), y1), min(max(t4, y0), y1)))
    poly = [
        (cx0, y0), (cx1, y0),
        (cx1, t1), (wx1, t1),
        (wx1, t2), (x1, t2),
        (x1, t3), (wx1, t3),
        (wx1, t4), (cx1, t4),
        (cx1, y1), (cx0, y1),
        (cx0, t4), (wx0, t4),
        (wx0, t3), (x0, t3),
        (x0, t2), (wx0, t2),
        (wx0, t1), (cx0, t1),
    ]
    notches = [
        (x0, y0, cx0 - x0, t1 - y0),
        (x0, t1, wx0 - x0, t2 - t1),
        (cx1, y0, x1 - cx1, t1 - y0),
        (wx1, t1, x1 - wx1, t2 - t1),
        (x0, t3, wx0 - x0, t4 - t3),
        (x0, t4, cx0 - x0, y1 - t4),
        (wx1, t3, x1 - wx1, t4 - t3),
        (cx1, t4, x1 - cx1, y1 - t4),
    ]
    return poly, notches


def inset_area(area: CutArea, margin: float) -> CutArea:
    """Área recortable con un margen de seguridad extra por todos los lados."""
    if margin <= 0:
        return area
    x0, y0, bw, bh = area.bbox
    nbw = max(1.0, bw - 2 * margin)
    nbh = max(1.0, bh - 2 * margin)
    nx0 = x0 + (bw - nbw) / 2.0
    ny0 = y0 + (bh - nbh) / 2.0
    poly, notches = _bands_polygon(nx0, ny0, nbw, nbh)
    return CutArea(page_w=area.page_w, page_h=area.page_h, poly=poly,
                   bbox=(nx0, ny0, nbw, nbh), notches=notches,
                   machine=area.machine)


def cut_area(page_w: float, page_h: float, machine: str = "estandar",
             paper_key: str | None = None, ds: bool = False) -> CutArea:
    """Calcula el área recortable para una página (mm) y máquina.

    `paper_key` indica el tamaño base para buscar los máximos oficiales
    (A4, A3, ...). Si es None se intenta deducir por coincidencia de
    dimensiones (con la página en cualquier orientación).
    `ds=True` devuelve el rectángulo SEGURO de Design Space (sin escalones,
    ~2,15 cm de margen por lado en A4) para que el PNG se importe sin que DS
    pida redimensionar.
    """
    if paper_key is None:
        paper_key = _match_paper(page_w, page_h)
    portrait_w, portrait_h = PAPER_SIZES.get(paper_key, (page_w, page_h))
    max_h, max_v = OFFICIAL_MAX.get(paper_key, _derive_max(page_w, page_h))
    if machine == "joy":
        # Cricut Joy 2: el máximo horizontal del papel se reduce mucho
        override = MACHINE_A4_OVERRIDE.get("joy")
        if override:
            max_h, max_v = override

    landscape = page_w >= page_h
    # En vertical del papel: max_v va a lo largo del lado largo (portrait_h).
    # En apaisado se intercambian.
    bw = max_v if landscape else max_h   # extensión horizontal del área útil
    bh = max_h if landscape else max_v   # extensión vertical del área útil
    bw = min(bw, page_w)
    bh = min(bh, page_h)

    x0 = (page_w - bw) / 2.0
    y0 = (page_h - bh) / 2.0

    if ds:
        # --- máximo RECTANGULAR real de Design Space --------------------
        # Para importar el PNG en Design Space sin que pida redimensionar:
        # el diseño debe caber en el mayor rectángulo interior del área de
        # Print Then Cut (tabla DS_RECT_MAX). Se centra en la hoja (como
        # DS), se limita al área de la máquina y se deja un pelín para el
        # redondeo a píxeles del guardado.
        base = DS_RECT_MAX.get(paper_key)
        if base is None:
            # tamaño sin dato oficial (A5, personalizado): se escala el A4
            esc0 = math.sqrt(max(1e-9, page_w * page_h) / (210.0 * 297.0))
            base = (DS_RECT_MAX["A4"][0] * esc0, DS_RECT_MAX["A4"][1] * esc0)
        dw = min(max(10.0, base[0] - DS_SAFE_EPS), bw)
        dh = min(max(10.0, base[1] - DS_SAFE_EPS), bh)
        dx = min(max((page_w - dw) / 2.0, x0), x0 + bw - dw)
        dy = min(max((page_h - dh) / 2.0, y0), y0 + bh - dh)
        poly = [(dx, dy), (dx + dw, dy), (dx + dw, dy + dh), (dx, dy + dh)]
        return CutArea(page_w=page_w, page_h=page_h, poly=poly,
                       bbox=(dx, dy, dw, dh), notches=[], machine=machine)

    # --- límites OFICIALES (calibrados sobre la referencia del usuario) ---
    # El área útil es el máximo oficial (186×272.3 en A4) y los ESCALONES son
    # los de la guía real de Design Space medidos en
    # `assets/Cricut_A5_Limites_300ppp.png` (STEP1/STEP2). El contenido puede
    # llegar a esos límites; las marcas se colocan abrazándolo por fuera.
    poly, notches = _bands_polygon(x0, y0, bw, bh)
    return CutArea(page_w=page_w, page_h=page_h, poly=poly, bbox=(x0, y0, bw, bh),
                   notches=notches, machine=machine)


def _match_paper(page_w: float, page_h: float) -> str:
    for key, (pw, ph) in PAPER_SIZES.items():
        if (abs(pw - page_w) < 0.5 and abs(ph - page_h) < 0.5) or \
           (abs(ph - page_w) < 0.5 and abs(pw - page_h) < 0.5):
            return key
    return ""


def _derive_max(page_w: float, page_h: float) -> tuple[float, float]:
    """Para tamaños sin entrada oficial (p. ej. personalizados) se aplican los
    márgenes equivalentes de A4 (~13.5 mm por lado)."""
    margin_x, margin_y = 13.5, 13.6
    portrait = page_h >= page_w
    if not portrait:
        page_w, page_h = page_h, page_w
    max_h = max(10.0, page_w - 2 * margin_x)
    max_v = max(10.0, page_h - 2 * margin_y)
    return (max_h, max_v) if portrait else (max_v, max_h)


def page_pixel_size(page_w_mm: float, page_h_mm: float, dpi: float) -> tuple[int, int]:
    """Píxeles de la página completa a la resolución dada."""
    return (max(1, round(page_w_mm / 25.4 * dpi)),
            max(1, round(page_h_mm / 25.4 * dpi)))


def mm_to_px(mm: float, dpi: float) -> int:
    return max(1, int(round(mm / 25.4 * dpi)))


def px_to_mm(px: float, dpi: float) -> float:
    return px / dpi * 25.4


def rotated_size(w: float, h: float, angle_deg: float) -> tuple[float, float]:
    """Tamaño del bbox de un rect w x h rotado angle_deg grados."""
    a = math.radians(angle_deg)
    c, s = abs(math.cos(a)), abs(math.sin(a))
    return (w * c + h * s, w * s + h * c)


def page_options() -> list[dict]:
    """Opciones de tamaño de página para la UI (la orientación se elige aparte)."""
    out = []
    for key, (pw, ph) in PAPER_SIZES.items():
        out.append({"key": key, "label": f"{key} ({pw:g}×{ph:g} mm)",
                    "w": pw, "h": ph})
    out.append({"key": "custom", "label": tr("Personalizado"), "w": 0, "h": 0})
    return out
